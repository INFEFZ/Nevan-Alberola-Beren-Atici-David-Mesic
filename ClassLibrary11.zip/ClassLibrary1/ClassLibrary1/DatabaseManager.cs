﻿using System;
using System.Data.SqlClient;

namespace DatenbankManager_Bibliotek
{
    /// <summary>
    /// Diese Klasse verwaltet alle Operationen zur Validierung von Kreditkartendaten und das Protokollieren von Validierungsversuchen.
    /// </summary>
    public class DatabaseManager
    {
        /// <summary>
        /// Fest definierter Verbindungsstring für den SQL Server.
        /// </summary>
        private string connectionString = "Data Source=localhost\\MSSQLSERVER1;Initial Catalog=KreditkarteDB;Integrated Security=True";

        /// <summary>
        /// Methode zur Validierung der Kartendetails.
        /// </summary>
        /// <param name="firstName">Vorname des Karteninhabers</param>
        /// <param name="lastName">Nachname des Karteninhabers</param>
        /// <param name="cardNumber">Die Kartennummer</param>
        /// <param name="cvv">Der Sicherheitscode (CVV) der Karte</param>
        /// <param name="expiryDate">Das Ablaufdatum der Karte im Format MM/YY</param>
        /// <param name="cardType">Der Typ der Karte (z.B. Visa, MasterCard)</param>
        /// <returns>Gibt true zurück, wenn die Karte erfolgreich validiert wurde, andernfalls false</returns>
        public bool ValidateCard(string firstName, string lastName, string cardNumber, string cvv, string expiryDate, string cardType)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Abfrage zur Überprüfung, ob die Kartendetails übereinstimmen
                string query = @"
                    SELECT CardID 
                    FROM Cards 
                    WHERE FirstName = @FirstName 
                      AND LastName = @LastName 
                      AND CardNumber = @CardNumber 
                      AND CVV = @CVV 
                      AND ExpiryDate = @ExpiryDate 
                      AND CardType = @CardType";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@CardNumber", cardNumber);
                    command.Parameters.AddWithValue("@CVV", cvv);
                    command.Parameters.AddWithValue("@ExpiryDate", expiryDate);
                    command.Parameters.AddWithValue("@CardType", cardType);

                    SqlDataReader reader = command.ExecuteReader();

                    // Wenn die Kartendetails korrekt sind
                    if (reader.Read())
                    {
                        LogCardValidation(cardNumber, true); // Protokolliere erfolgreichen Versuch
                        return true; // Karte erfolgreich validiert
                    }
                    else
                    {
                        LogCardValidation(cardNumber, false); // Protokolliere fehlgeschlagenen Versuch
                        return false; // Karte nicht gefunden oder ungültig
                    }
                }
            }
        }

        /// <summary>
        /// Validiert die Kreditkartennummer mit dem Luhn-Algorithmus (Modulo 10).
        /// </summary>
        /// <param name="cardNumber">Die zu validierende Kreditkartennummer</param>
        /// <returns>Gibt true zurück, wenn die Kreditkartennummer gültig ist, andernfalls false</returns>
        public bool ValidateCardNumberWithLuhn(string cardNumber)
        {
            // Entferne alle Leerzeichen oder Trennzeichen in der Kartennummer
            cardNumber = cardNumber.Replace(" ", "");

            int sum = 0;
            bool alternate = false;

            // Iteriere durch die Kartennummer von rechts nach links
            for (int i = cardNumber.Length - 1; i >= 0; i--)
            {
                // Hole die aktuelle Ziffer
                int n;
                if (!int.TryParse(cardNumber[i].ToString(), out n))
                {
                    return false; // Ungültige Zeichen in der Kartennummer
                }

                if (alternate)
                {
                    // Verdopple jede zweite Ziffer
                    n *= 2;
                    if (n > 9)
                    {
                        n -= 9; // Wenn die Zahl größer als 9 ist, subtrahiere 9
                    }
                }

                sum += n;
                alternate = !alternate; // Wechsle bei jeder Schleife
            }

            // Prüfe, ob die Summe ein Vielfaches von 10 ist
            return (sum % 10 == 0);
        }

        /// <summary>
        /// Protokolliert den Validierungsversuch in der Logs-Tabelle.
        /// </summary>
        /// <param name="cardNumber">Die Kartennummer, die validiert wird</param>
        /// <param name="isSuccess">Gibt an, ob die Validierung erfolgreich war</param>
        private void LogCardValidation(string cardNumber, bool isSuccess)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Logs (CardNumber, Success, AttemptDate) VALUES (@CardNumber, @Success, GETDATE())";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CardNumber", cardNumber);
                command.Parameters.AddWithValue("@Success", isSuccess ? 1 : 0);

                command.ExecuteNonQuery();
            }
        }
    }
}
